import {
	METADATA_CACHE_EXTERNAL_WRITE_LOCK_DURATION,
	MetadataManager,
} from 'meta-bind-core/src/metadata/MetadataManager';

import { DEFAULT_SETTINGS, type MetaBindPluginSettings } from 'meta-bind-core/src/Settings';
import {
	GlobalMetadataSource,
	InternalMetadataSource,
	ScopeMetadataSource,
} from 'meta-bind-core/src/metadata/InternalMetadataSources';
import {
	type BindTargetDeclaration,
	BindTargetStorageType,
} from 'meta-bind-core/src/parsers/bindTargetParser/BindTargetDeclaration';
import { setFirstWeekday } from 'meta-bind-core/src/utils/DatePickerUtils';
import { TestAPI } from './TestAPI';
import { TestInternalAPI } from './TestInternalAPI';
import { InputFieldMountable } from 'meta-bind-core/src/fields/inputFields/InputFieldMountable';
import type { InputField } from 'meta-bind-core/src/fields/inputFields/InputFieldFactory';
import { expect, type Mock, spyOn } from 'bun:test';
import { getUUID } from 'meta-bind-core/src/utils/Utils';
import type { Metadata } from 'meta-bind-core/src/metadata/MetadataSource';
import { Signal } from 'meta-bind-core/src/utils/Signal';
import { parsePropPath } from 'meta-bind-core/src/utils/prop/PropParser';
import { MountableManager } from 'meta-bind-core/src/MountableManager';
import { RenderChildType } from 'meta-bind-core/src/config/APIConfigs';
import { MetaBind } from 'meta-bind-core/src';
import { DomHelpers } from 'meta-bind-core/src/api/DomHelpers';
import { TestFileAPI } from './TestFileAPI';

class TestDomHelpers extends DomHelpers {
	override get activeDocument(): Document {
		return document;
	}
}

/**
 * A default value to indicate that a field should be it's the default value.
 */
export const DEFAULT_VALUE_INDICATOR = '$$default$$';
export const TEST_FILE_PATH = 'test/file.md';

export interface UninitializedTestInputField {
	mountable: InputFieldMountable;
}

export interface TestInputField {
	mountable: InputFieldMountable;
	field: InputField;
	svelteUpdateSpy: Mock<(value: any) => void>;
}

export interface TestComponents {
	api: TestAPI;
	internal: TestInternalAPI;
	file: TestFileAPI;
}

export class TestMetaBind extends MetaBind<TestComponents> {
	public settings: MetaBindPluginSettings;

	public uninitializedTestInputFields: UninitializedTestInputField[] = [];
	public testInputFields: TestInputField[] = [];

	public inTestSetup: boolean = true;
	public metadataManagerInternalUpdateSpy:
		| Mock<(value: unknown, bindTarget: BindTargetDeclaration) => void>
		| undefined;

	constructor() {
		super();
		this.domHelpers = new TestDomHelpers();

		this.setComponents({
			api: new TestAPI(this),
			internal: new TestInternalAPI(this),
			file: new TestFileAPI(this),
		});

		this.metadataManager = new MetadataManager();
		this.setUpMetadataManager();

		this.mountableManager = new MountableManager();

		this.settings = structuredClone(DEFAULT_SETTINGS);
		this.settings.enableJs = true;

		setFirstWeekday(this.settings.firstWeekday);
	}

	getSettings(): MetaBindPluginSettings {
		return this.settings;
	}

	saveSettings(settings: MetaBindPluginSettings): void {
		this.settings = settings;
	}

	setUpMetadataManager(): void {
		this.metadataManager.registerSource(
			new InternalMetadataSource(BindTargetStorageType.FRONTMATTER, this.metadataManager),
		);
		this.metadataManager.registerSource(
			new InternalMetadataSource(BindTargetStorageType.MEMORY, this.metadataManager),
		);
		this.metadataManager.registerSource(
			new GlobalMetadataSource(BindTargetStorageType.GLOBAL_MEMORY, this.metadataManager),
		);
		this.metadataManager.registerSource(new ScopeMetadataSource(BindTargetStorageType.SCOPE, this.metadataManager));

		this.metadataManager.setDefaultSource(BindTargetStorageType.FRONTMATTER);
	}

	addTestInputField(declaration: string, filePath?: string): number {
		if (!this.inTestSetup) {
			throw new Error('Cannot add test input field outside of test setup');
		}

		const mountable = this.api.createInputFieldMountable(filePath ?? TEST_FILE_PATH, {
			declaration: declaration,
			renderChildType: RenderChildType.BLOCK,
			scope: undefined,
		});

		const test: UninitializedTestInputField = { mountable: mountable };

		this.uninitializedTestInputFields.push(test);

		return this.uninitializedTestInputFields.length - 1;
	}

	initializeTest(): void {
		this.testInputFields = new Array(this.uninitializedTestInputFields.length);

		this.metadataManagerInternalUpdateSpy = spyOn(this.metadataManager, 'write');

		this.inTestSetup = false;
	}

	initializeAllTestInputFields(): void {
		for (let i = 0; i < this.uninitializedTestInputFields.length; i++) {
			this.initializeTestInputField(i);
		}
	}

	initializeTestInputField(index: number): void {
		if (this.inTestSetup) {
			throw new Error('Cannot initialize test input field inside of test setup');
		}

		if (index < 0 || index >= this.uninitializedTestInputFields.length) {
			throw new Error('Invalid index');
		}

		const test = this.uninitializedTestInputFields[index];
		test.mountable.mount(document.body);

		const field = test.mountable.inputField as InputField;
		const svelteUpdateSpy = spyOn(field.svelteWrapper!, 'setValue');
		this.testInputFields[index] = { mountable: test.mountable, field, svelteUpdateSpy };
	}

	getTestInputField(index: number): TestInputField {
		if (index < 0 || index >= this.testInputFields.length) {
			throw new Error('Invalid index');
		}

		return this.testInputFields[index];
	}

	getTestInputFieldValue(index: number): unknown {
		return this.getTestInputField(index).field.getValue();
	}

	getAllTestInputFieldValues(): unknown[] {
		return this.testInputFields.map(x => x.field.getValue());
	}

	getAllTestInputFieldDefaultValues(): unknown[] {
		return this.testInputFields.map(x => x.field.getDefaultValue());
	}

	getAllTestInputFieldSpys(): Mock<(value: any) => void>[] {
		return this.testInputFields.map(x => x.svelteUpdateSpy);
	}

	setTestInputFieldValue(index: number, value: any): void {
		this.getTestInputField(index).field.setValue(value as never);
	}

	expectAllTestInputFieldSpysToHaveBeenCalledTimes(times: number[]): void {
		if (times.length !== this.testInputFields.length) {
			throw new Error('Invalid times length');
		}

		for (const [spy, time] of this.getAllTestInputFieldSpys().map((x, i) => [x, times[i]] as const)) {
			expect(spy).toHaveBeenCalledTimes(time);
		}
	}

	expectAllTestInputFieldSpysToHaveBeenCalledTimesOrLess(times: number[]): void {
		if (times.length !== this.testInputFields.length) {
			throw new Error('Invalid times length');
		}

		for (const [spy, time] of this.getAllTestInputFieldSpys().map((x, i) => [x, times[i]] as const)) {
			expect(spy.mock.calls.length).toBeLessThanOrEqual(time);
		}
	}

	expectAllTestInputFieldValuesToEqual(values: any[]): void {
		if (values.length !== this.testInputFields.length) {
			throw new Error('Invalid values length');
		}

		for (const [testInputField, value] of this.testInputFields.map((x, i) => [x, values[i]] as const)) {
			if (value === DEFAULT_VALUE_INDICATOR) {
				expect(testInputField.field.getValue()).toEqual(testInputField.field.getDefaultValue());
			} else {
				expect(testInputField.field.getValue()).toEqual(value);
			}
		}
	}

	createInitialCache(initialMetadata: Metadata, filePath?: string): void {
		// setting the initial metadata only works if the cache is already initialized, which happens when someone subscribes to the file
		const subscription = this.metadataManager.subscribe(
			getUUID(),
			new Signal<unknown>(undefined),
			{
				storageType: BindTargetStorageType.FRONTMATTER,
				storagePath: filePath ?? TEST_FILE_PATH,
				storageProp: parsePropPath(['something_unused']),
				listenToChildren: false,
			},
			() => {},
		);

		this.setCacheExternally(initialMetadata);

		subscription.unsubscribe();

		// make sure the metadata is set correctly
		expect<Metadata | undefined>(this.getCacheMetadata()).toEqual(initialMetadata);
	}

	setCacheExternally(metadata: Metadata, filePath?: string): void {
		const source = this.metadataManager.getSource(BindTargetStorageType.FRONTMATTER);
		if (!source) {
			throw new Error('source not found');
		}
		this.metadataManager.onExternalUpdate(source, filePath ?? TEST_FILE_PATH, metadata);
	}

	getCacheMetadata(filePath?: string): Metadata | undefined {
		const source = this.metadataManager.getSource(BindTargetStorageType.FRONTMATTER);
		if (!source) {
			throw new Error('source not found');
		}
		const cacheItem = source.getCacheItemForStoragePath(filePath ?? TEST_FILE_PATH);
		if (!cacheItem) {
			throw new Error('cache item not found');
		}

		return source.readEntireCacheItem(cacheItem);
	}

	async cycleMetadataManager(): Promise<void> {
		return this.metadataManager.cycle();
	}

	expectMetadataManagerToHaveUpdatedTimes(times: number): void {
		expect(this.metadataManagerInternalUpdateSpy).toHaveBeenCalledTimes(times);
	}

	public async cycleMetadataManagerUntilThreshold(): Promise<void> {
		for (let i = 0; i < METADATA_CACHE_EXTERNAL_WRITE_LOCK_DURATION; i++) {
			await this.cycleMetadataManager();
		}
	}
}
