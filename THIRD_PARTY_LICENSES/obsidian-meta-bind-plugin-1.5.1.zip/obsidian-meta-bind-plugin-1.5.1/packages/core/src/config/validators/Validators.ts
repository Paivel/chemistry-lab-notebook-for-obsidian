import type { ParsingRange } from '@lemons_dev/parsinom';
import type {
	ButtonGroupOptions,
	ButtonOptions,
	EmbedOptions,
	InputFieldOptions,
	JsViewFieldOptions,
	TableOptions,
	ViewFieldOptions,
} from 'meta-bind-core/src/config/APIConfigs';
import { FieldType, NotePosition, RenderChildType } from 'meta-bind-core/src/config/APIConfigs';
import { InputFieldType } from 'meta-bind-core/src/config/FieldConfigs';
import { V_ButtonConfig } from 'meta-bind-core/src/config/validators/ButtonConfigValidators';
import { FieldMountable } from 'meta-bind-core/src/fields/FieldMountable';
import { BindTargetScope } from 'meta-bind-core/src/metadata/BindTargetScope';
import type {
	BindTargetDeclaration,
	SimplePropAccess,
	UnvalidatedBindTargetDeclaration,
	UnvalidatedPropAccess,
} from 'meta-bind-core/src/parsers/bindTargetParser/BindTargetDeclaration';
import type { SimpleButtonGroupDeclaration } from 'meta-bind-core/src/parsers/ButtonParser';
import type { SimpleFieldArgument, UnvalidatedFieldArgument } from 'meta-bind-core/src/parsers/FieldDeclaration';
import type {
	SimpleInputFieldDeclaration,
	UnvalidatedInputFieldDeclaration,
} from 'meta-bind-core/src/parsers/inputFieldParser/InputFieldDeclaration';
import type { ParsingResultNode } from 'meta-bind-core/src/parsers/nomParsers/GeneralNomParsers';
import type {
	SimpleJsViewFieldBindTargetMapping,
	SimpleJsViewFieldDeclaration,
	SimpleViewFieldDeclaration,
	UnvalidatedViewFieldDeclaration,
} from 'meta-bind-core/src/parsers/viewFieldParser/ViewFieldDeclaration';
import { ErrorCollection } from 'meta-bind-core/src/utils/errors/ErrorCollection';
import { Mountable } from 'meta-bind-core/src/utils/Mountable';
import { PropAccessType } from 'meta-bind-core/src/utils/prop/PropAccess';
import { PropPath } from 'meta-bind-core/src/utils/prop/PropPath';
import { Signal } from 'meta-bind-core/src/utils/Signal';
import { schemaForType, zodFunction } from 'meta-bind-core/src/utils/ZodUtils';
import { z } from 'zod';

export const V_FilePath = schemaForType<string>()(z.string());

export const V_RenderChildType = schemaForType<RenderChildType>()(z.enum(RenderChildType));

export const V_FieldType = schemaForType<FieldType>()(z.enum(FieldType));

export const V_InputFieldType = schemaForType<InputFieldType>()(z.enum(InputFieldType));

// This is temporarily changed to `z.any()` from `z.instanceof(HTMLElement)`, because the latter does not work in popout windows or PDF exports.
export const V_HTMLElement = schemaForType<HTMLElement>()(z.any());

export const V_BindTargetScope = schemaForType<BindTargetScope>()(z.instanceof(BindTargetScope));

export const V_Signal = schemaForType<Signal<unknown>>()(z.instanceof(Signal));

export const V_VoidFunction = schemaForType<() => void>()(zodFunction<() => void>());

export const V_FieldMountable = schemaForType<FieldMountable>()(z.instanceof(FieldMountable));
export const V_Mountable = schemaForType<Mountable>()(z.instanceof(Mountable));

export const V_NotePosition = schemaForType<NotePosition>()(z.instanceof(NotePosition));

export const V_ParsingRange = schemaForType<ParsingRange>()(
	z.object({
		from: z.number(),
		to: z.number(),
	}),
);

export const V_ParsingResultNode = schemaForType<ParsingResultNode>()(
	z.object({
		value: z.string(),
		position: V_ParsingRange.optional(),
	}),
);

export const V_UnvalidatedFieldArgument = schemaForType<UnvalidatedFieldArgument>()(
	z.object({
		name: V_ParsingResultNode,
		value: V_ParsingResultNode.array(),
	}),
);

export const V_UnvalidatedPropAccess = schemaForType<UnvalidatedPropAccess>()(
	z.object({
		type: z.enum(PropAccessType),
		prop: V_ParsingResultNode,
	}),
);

export const V_UnvalidatedBindTargetDeclaration = schemaForType<UnvalidatedBindTargetDeclaration>()(
	z.object({
		storageType: V_ParsingResultNode.optional(),
		storagePath: V_ParsingResultNode.optional(),
		storageProp: V_UnvalidatedPropAccess.array(),
		listenToChildren: z.boolean(),
	}),
);

export const V_UnvalidatedInputFieldDeclaration = schemaForType<UnvalidatedInputFieldDeclaration>()(
	z.object({
		declarationString: z.string().optional(),
		inputFieldType: V_ParsingResultNode.optional(),
		templateName: V_ParsingResultNode.optional(),
		bindTarget: V_UnvalidatedBindTargetDeclaration.optional(),
		arguments: V_UnvalidatedFieldArgument.array(),
		errorCollection: z.instanceof(ErrorCollection),
	}),
);

export const V_UnvalidatedViewFieldDeclaration = schemaForType<UnvalidatedViewFieldDeclaration>()(
	z.object({
		declarationString: z.string().optional(),
		templateDeclaration: z.array(z.union([z.string(), V_UnvalidatedBindTargetDeclaration])).optional(),
		viewFieldType: V_ParsingResultNode.optional(),
		arguments: V_UnvalidatedFieldArgument.array(),
		writeToBindTarget: V_UnvalidatedBindTargetDeclaration.optional(),
		errorCollection: z.instanceof(ErrorCollection),
	}),
);

export const V_BindTargetDeclaration = schemaForType<BindTargetDeclaration>()(
	z.object({
		storageType: z.string(),
		storagePath: z.string(),
		storageProp: z.instanceof(PropPath),
		listenToChildren: z.boolean(),
	}),
);

export const V_SimpleFieldArgument = schemaForType<SimpleFieldArgument>()(
	z.object({
		name: z.string(),
		value: z.string().array(),
	}),
);

export const V_SimplePropAccess = schemaForType<SimplePropAccess>()(
	z.object({
		type: z.enum(PropAccessType),
		prop: z.string(),
	}),
);

export const V_SimpleInputFieldDeclaration = schemaForType<SimpleInputFieldDeclaration>()(
	z.object({
		inputFieldType: V_InputFieldType.optional(),
		templateName: z.string().optional(),
		bindTarget: V_BindTargetDeclaration.optional(),
		arguments: V_SimpleFieldArgument.array().optional(),
	}),
);

export const V_SimpleViewFieldDeclaration = schemaForType<SimpleViewFieldDeclaration>()(
	z.object({
		viewFieldType: V_InputFieldType.optional(),
		templateDeclaration: z.union([z.string(), V_BindTargetDeclaration]).array().optional(),
		arguments: V_SimpleFieldArgument.array().optional(),
		writeToBindTarget: V_BindTargetDeclaration.optional(),
	}),
);

export const V_SimpleJsViewFieldBindTargetMapping = schemaForType<SimpleJsViewFieldBindTargetMapping>()(
	z.object({
		bindTarget: V_BindTargetDeclaration,
		name: z.string(),
	}),
);

export const V_SimpleJsViewFieldDeclaration = schemaForType<SimpleJsViewFieldDeclaration>()(
	z.object({
		bindTargetMappings: V_SimpleJsViewFieldBindTargetMapping.array(),
		writeToBindTarget: V_BindTargetDeclaration.optional(),
		code: z.string(),
	}),
);

export const V_SimpleInlineButtonDeclaration = schemaForType<SimpleButtonGroupDeclaration>()(
	z.object({
		referencedButtonIds: z.string().array(),
	}),
);

export const V_InputFieldOptions = schemaForType<InputFieldOptions>()(
	z.object({
		renderChildType: V_RenderChildType,
		declaration: z.union([z.string(), V_SimpleInputFieldDeclaration]),
		scope: V_BindTargetScope.optional(),
	}),
);

export const V_ViewFieldOptions = schemaForType<ViewFieldOptions>()(
	z.object({
		renderChildType: V_RenderChildType,
		declaration: z.union([z.string(), V_SimpleViewFieldDeclaration]),
		scope: V_BindTargetScope.optional(),
	}),
);

export const V_JsViewFieldOptions = schemaForType<JsViewFieldOptions>()(
	z.object({
		declaration: z.union([z.string(), V_SimpleJsViewFieldDeclaration]),
	}),
);

export const V_TableFieldOptions = schemaForType<TableOptions>()(
	z.object({
		bindTarget: V_BindTargetDeclaration,
		tableHead: z.string().array(),
		columns: z.array(z.union([V_SimpleInputFieldDeclaration, V_SimpleViewFieldDeclaration, z.string()])),
	}),
);

export const V_InlineButtonOptions = schemaForType<ButtonGroupOptions>()(
	z.object({
		renderChildType: V_RenderChildType,
		declaration: z.union([z.string(), V_SimpleInlineButtonDeclaration]),
		position: V_NotePosition.optional(),
	}),
);

export const V_ButtonOptions = schemaForType<ButtonOptions>()(
	z.object({
		declaration: z.union([z.string(), V_ButtonConfig]),
		position: V_NotePosition.optional(),
		isPreview: z.boolean(),
	}),
);

export const V_EmbedOptions = schemaForType<EmbedOptions>()(
	z.object({
		depth: z.number(),
		content: z.string(),
	}),
);
