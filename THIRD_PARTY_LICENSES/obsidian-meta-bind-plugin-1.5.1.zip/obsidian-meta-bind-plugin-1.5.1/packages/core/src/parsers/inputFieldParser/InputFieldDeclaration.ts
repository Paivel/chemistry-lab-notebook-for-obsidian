import type { InputFieldType } from 'meta-bind-core/src/config/FieldConfigs';
import type { InputFieldArgumentContainer } from 'meta-bind-core/src/fields/fieldArguments/inputFieldArguments/InputFieldArgumentContainer';
import type {
	BindTargetDeclaration,
	UnvalidatedBindTargetDeclaration,
} from 'meta-bind-core/src/parsers/bindTargetParser/BindTargetDeclaration';
import type {
	FieldDeclaration,
	SimpleFieldArgument,
	UnvalidatedFieldArgument,
} from 'meta-bind-core/src/parsers/FieldDeclaration';
import type { ParsingResultNode } from 'meta-bind-core/src/parsers/nomParsers/GeneralNomParsers';

export interface InputFieldDeclaration extends FieldDeclaration {
	inputFieldType: InputFieldType;
	bindTarget: BindTargetDeclaration | undefined;
	argumentContainer: InputFieldArgumentContainer;
}

export interface PartialUnvalidatedInputFieldDeclaration {
	inputFieldType?: ParsingResultNode | undefined;
	templateName?: ParsingResultNode | undefined;
	bindTarget?: UnvalidatedBindTargetDeclaration | undefined;
	arguments: UnvalidatedFieldArgument[];
}

export interface UnvalidatedInputFieldDeclaration extends PartialUnvalidatedInputFieldDeclaration, FieldDeclaration {}

export interface SimpleInputFieldDeclaration {
	inputFieldType?: InputFieldType | undefined;
	templateName?: string | undefined;
	bindTarget?: BindTargetDeclaration | undefined;
	arguments?: SimpleFieldArgument[] | undefined;
}
