import type { IMetadataSubscription } from 'meta-bind-core/src/metadata/IMetadataSubscription';
import type {
	FilePathMetadataCacheItem,
	GlobalMetadataCacheItem,
	IMetadataCacheItem,
} from 'meta-bind-core/src/metadata/MetadataCacheItem';
import type { MetadataManager } from 'meta-bind-core/src/metadata/MetadataManager';
import type { IMetadataSource, Metadata } from 'meta-bind-core/src/metadata/MetadataSource';
import { FilePathMetadataSource } from 'meta-bind-core/src/metadata/MetadataSource';
import type { BindTargetDeclaration } from 'meta-bind-core/src/parsers/bindTargetParser/BindTargetDeclaration';
import type { BindTargetParser } from 'meta-bind-core/src/parsers/bindTargetParser/BindTargetParser';
import type { ParsingResultNode } from 'meta-bind-core/src/parsers/nomParsers/GeneralNomParsers';
import { ParsingValidationError } from 'meta-bind-core/src/parsers/ParsingError';
import { ErrorLevel, MetaBindInternalError } from 'meta-bind-core/src/utils/errors/MetaBindErrors';
import type { PropPath } from 'meta-bind-core/src/utils/prop/PropPath';
import { PropUtils } from 'meta-bind-core/src/utils/prop/PropUtils';

export class InternalMetadataSource extends FilePathMetadataSource<FilePathMetadataCacheItem> {
	public readExternal(_storagePath: string): Metadata {
		return {};
	}

	public getDefaultCacheItem(storagePath: string): FilePathMetadataCacheItem {
		return {
			data: {},
			storagePath: storagePath,
			...this.manager.constructDefaultCacheItem(),
		};
	}

	public syncExternal(_cacheItem: FilePathMetadataCacheItem): Promise<void> {
		return Promise.resolve();
	}
}

export class TestMetadataSource extends FilePathMetadataSource<FilePathMetadataCacheItem> {
	externalMetadata: Record<string, Metadata>;

	constructor(id: string, manager: MetadataManager, externalMetadata: Record<string, Metadata> = {}) {
		super(id, manager);

		this.externalMetadata = externalMetadata;
	}

	public readExternal(storagePath: string): Metadata {
		return this.externalMetadata[storagePath] ?? {};
	}

	public getDefaultCacheItem(storagePath: string): FilePathMetadataCacheItem {
		return {
			data: this.readExternal(storagePath),
			storagePath: storagePath,
			...this.manager.constructDefaultCacheItem(),
		};
	}

	public syncExternal(cacheItem: FilePathMetadataCacheItem): Promise<void> {
		this.externalMetadata[cacheItem.storagePath] = cacheItem.data;
		return Promise.resolve();
	}
}

export class GlobalMetadataSource implements IMetadataSource<GlobalMetadataCacheItem> {
	public readonly id: string;
	public readonly manager: MetadataManager;
	public readonly cache: GlobalMetadataCacheItem;

	constructor(id: string, manager: MetadataManager) {
		this.id = id;
		this.manager = manager;

		this.cache = {
			data: {},
			...this.manager.constructDefaultCacheItem(),
		};
	}

	public getOrCreateCacheItem(_storagePath: string): GlobalMetadataCacheItem {
		return this.cache;
	}

	public validateStoragePath(
		storagePath: ParsingResultNode,
		hadStoragePath: boolean,
		bindTargetDeclaration: string | undefined,
		_parser: BindTargetParser,
	): string {
		if (hadStoragePath) {
			throw new ParsingValidationError(
				ErrorLevel.ERROR,
				'Bind target validator',
				`Failed to parse bind target. Bind target storage type 'global_memory' does not support a storage path.`,
				bindTargetDeclaration,
				storagePath.position,
			);
		}
		return '';
	}

	public deleteCache(_cacheItem: GlobalMetadataCacheItem): void {
		// noop
	}

	public getCacheItemForStoragePath(_storagePath: string): GlobalMetadataCacheItem | undefined {
		return this.cache;
	}

	public getCacheItems(): GlobalMetadataCacheItem[] {
		return [this.cache];
	}

	public onCycle(_cacheItem: GlobalMetadataCacheItem): void {
		// noop
	}

	public readCache(bindTarget: BindTargetDeclaration): unknown {
		return this.readCacheItem(this.cache, bindTarget.storageProp);
	}

	public readCacheItem(cacheItem: GlobalMetadataCacheItem, propPath: PropPath): unknown {
		return PropUtils.tryGet(cacheItem.data, propPath);
	}

	public shouldDelete(_cacheItem: GlobalMetadataCacheItem): boolean {
		return false;
	}

	public subscribe(subscription: IMetadataSubscription): GlobalMetadataCacheItem {
		this.cache.subscriptions.push(subscription);

		return this.cache;
	}

	public syncExternal(_cacheItem: GlobalMetadataCacheItem): Promise<void> {
		return Promise.resolve();
	}

	public unsubscribe(subscription: IMetadataSubscription): GlobalMetadataCacheItem {
		this.cache.subscriptions = this.cache.subscriptions.filter(x => x.uuid !== subscription.uuid);

		return this.cache;
	}

	public writeCache(value: unknown, bindTarget: BindTargetDeclaration): GlobalMetadataCacheItem {
		PropUtils.setAndCreate(this.cache.data, bindTarget.storageProp, value);

		return this.cache;
	}

	public writeEntireCache(value: Metadata, cacheItem: GlobalMetadataCacheItem): void {
		cacheItem.data = value;
	}

	public readEntireCacheItem(cacheItem: GlobalMetadataCacheItem): Metadata {
		return cacheItem.data;
	}

	public usesStoragePath(): boolean {
		return false;
	}
}

export class ScopeMetadataSource implements IMetadataSource<IMetadataCacheItem> {
	public readonly id: string;
	public readonly manager: MetadataManager;

	constructor(id: string, manager: MetadataManager) {
		this.id = id;
		this.manager = manager;
	}

	public getOrCreateCacheItem(_storagePath: string): IMetadataCacheItem {
		throw new MetaBindInternalError({
			errorLevel: ErrorLevel.CRITICAL,
			effect: 'action not permitted',
			cause: `source 'scope' should have no cache items or subscriptions`,
		});
	}

	public validateStoragePath(
		storagePath: ParsingResultNode,
		hadStoragePath: boolean,
		bindTargetDeclaration: string | undefined,
		_parser: BindTargetParser,
	): string {
		if (hadStoragePath) {
			throw new ParsingValidationError(
				ErrorLevel.ERROR,
				'Bind Target Validator',
				`Failed to parse bind target. Bind target storage type 'scope' does not support a storage path.`,
				bindTargetDeclaration,
				storagePath.position,
			);
		}
		return '';
	}

	public deleteCache(_cacheItem: IMetadataCacheItem): void {
		// noop
	}

	public getCacheItemForStoragePath(_storagePath: string): IMetadataCacheItem | undefined {
		return undefined;
	}

	public getCacheItems(): IMetadataCacheItem[] {
		return [];
	}

	public onCycle(_cacheItem: IMetadataCacheItem): void {
		// noop
	}

	public readCache(_bindTarget: BindTargetDeclaration): unknown {
		return undefined;
	}

	public readCacheItem(_cacheItem: IMetadataCacheItem, _propPath: PropPath): unknown {
		return undefined;
	}

	public shouldDelete(_cacheItem: IMetadataCacheItem): boolean {
		return true;
	}

	public subscribe(_subscription: IMetadataSubscription): IMetadataCacheItem {
		throw new MetaBindInternalError({
			errorLevel: ErrorLevel.CRITICAL,
			effect: 'action not permitted',
			cause: `source 'scope' should have no cache items or subscriptions`,
		});
	}

	public syncExternal(_cacheItem: IMetadataCacheItem): Promise<void> {
		return Promise.resolve();
	}

	public unsubscribe(_subscription: IMetadataSubscription): IMetadataCacheItem {
		throw new MetaBindInternalError({
			errorLevel: ErrorLevel.CRITICAL,
			effect: 'action not permitted',
			cause: `source 'scope' should have no cache items or subscriptions`,
		});
	}

	public writeCache(_value: unknown, _bindTarget: BindTargetDeclaration): IMetadataCacheItem {
		throw new MetaBindInternalError({
			errorLevel: ErrorLevel.CRITICAL,
			effect: 'action not permitted',
			cause: `source 'scope' should have no cache items or subscriptions`,
		});
	}

	public writeEntireCache(_value: Metadata, _cacheItem: IMetadataCacheItem): void {
		// noop
	}

	public readEntireCacheItem(_cacheItem: IMetadataCacheItem): Metadata {
		throw new MetaBindInternalError({
			errorLevel: ErrorLevel.CRITICAL,
			effect: 'action not permitted',
			cause: `source 'scope' should have no cache items or subscriptions`,
		});
	}

	public usesStoragePath(): boolean {
		return false;
	}
}
