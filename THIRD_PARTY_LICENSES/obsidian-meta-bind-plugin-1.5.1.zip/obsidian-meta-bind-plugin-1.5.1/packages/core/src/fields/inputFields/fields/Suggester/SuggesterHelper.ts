import type { ImageListSuggesterIPF } from 'meta-bind-core/src/fields/inputFields/fields/ImageListSuggester/ImageListSuggesterIPF';
import type { ImageSuggesterIPF } from 'meta-bind-core/src/fields/inputFields/fields/ImageSuggester/ImageSuggesterIPF';
import type { InlineListSuggesterIPF } from 'meta-bind-core/src/fields/inputFields/fields/InlineListSuggester/InlineListSuggesterIPF';
import type { ListSuggesterIPF } from 'meta-bind-core/src/fields/inputFields/fields/ListSuggester/ListSuggesterIPF';
import type { SuggesterIPF } from 'meta-bind-core/src/fields/inputFields/fields/Suggester/SuggesterIPF';

export type SuggesterLikeIFP = SuggesterIPF | ListSuggesterIPF | InlineListSuggesterIPF;

export type ImageSuggesterLikeIPF = ImageSuggesterIPF | ImageListSuggesterIPF;

export class SuggesterOption<T> {
	value: T;
	displayValue: string;
	displayDescription?: string;

	constructor(value: T, displayValue: string, displayDescription?: string) {
		this.value = value;
		this.displayValue = displayValue;
		this.displayDescription = displayDescription;
	}

	valueAsString(): string {
		return this.value?.toString() ?? 'null';
	}
}
