import type { MetaBind } from 'meta-bind-core/src';
import type {
	ButtonClickContext,
	ButtonConfig,
	ButtonContext,
	OpenButtonAction,
} from 'meta-bind-core/src/config/ButtonConfig';
import { ButtonActionType } from 'meta-bind-core/src/config/ButtonConfig';
import { AbstractButtonActionConfig } from 'meta-bind-core/src/fields/button/AbstractButtonActionConfig';
import { MDLinkParser } from 'meta-bind-core/src/parsers/MarkdownLinkParser';

export class OpenButtonActionConfig extends AbstractButtonActionConfig<OpenButtonAction> {
	constructor(mb: MetaBind) {
		super(ButtonActionType.OPEN, mb);
	}

	async run(
		_config: ButtonConfig | undefined,
		action: OpenButtonAction,
		filePath: string,
		_context: ButtonContext,
		click: ButtonClickContext,
	): Promise<void> {
		const newTab = click.openInNewTab() || (action.newTab ?? false);
		const link = MDLinkParser.interpretAsLink(action.link);
		if (!link) {
			throw new Error('Invalid link');
		}
		link.open(this.mb, filePath, newTab);
	}

	create(): Required<OpenButtonAction> {
		return { type: ButtonActionType.OPEN, link: '', newTab: true };
	}

	getActionLabel(): string {
		return 'Open a link';
	}
}
