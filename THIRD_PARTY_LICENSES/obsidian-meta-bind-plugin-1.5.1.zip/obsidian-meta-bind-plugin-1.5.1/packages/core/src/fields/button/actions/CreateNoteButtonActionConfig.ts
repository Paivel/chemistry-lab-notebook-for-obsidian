import type { MetaBind } from 'meta-bind-core/src';
import type {
	ButtonClickContext,
	ButtonConfig,
	ButtonContext,
	CreateNoteButtonAction,
} from 'meta-bind-core/src/config/ButtonConfig';
import { ButtonActionType } from 'meta-bind-core/src/config/ButtonConfig';
import { AbstractButtonActionConfig } from 'meta-bind-core/src/fields/button/AbstractButtonActionConfig';
import { ensureFileExtension, joinPath } from 'meta-bind-core/src/utils/Utils';

export class CreateNoteButtonActionConfig extends AbstractButtonActionConfig<CreateNoteButtonAction> {
	constructor(mb: MetaBind) {
		super(ButtonActionType.CREATE_NOTE, mb);
	}

	async run(
		_config: ButtonConfig | undefined,
		action: CreateNoteButtonAction,
		_filePath: string,
		_context: ButtonContext,
		click: ButtonClickContext,
	): Promise<void> {
		if (action.openIfAlreadyExists) {
			const filePath = ensureFileExtension(joinPath(action.folderPath ?? '', action.fileName), 'md');
			// if the file already exists, open it in the same tab
			if (await this.mb.file.exists(filePath)) {
				await this.mb.file.open(filePath, '', false);
				return;
			}
		}

		await this.mb.file.create(
			action.folderPath ?? '',
			action.fileName,
			'md',
			action.openNote ?? false,
			click.openInNewTab(),
		);
	}

	create(): Required<CreateNoteButtonAction> {
		return {
			type: ButtonActionType.CREATE_NOTE,
			folderPath: '/',
			fileName: 'Untitled',
			openNote: true,
			openIfAlreadyExists: false,
		};
	}

	getActionLabel(): string {
		return 'Create a new note';
	}
}
