import type { LifecycleHook } from 'meta-bind-core/src/api/API';
import type { MetaBindDate } from 'meta-bind-core/src/api/MetaBindDate';
import type {
	ImageSuggesterLikeIPF,
	SuggesterLikeIFP,
	SuggesterOption,
} from 'meta-bind-core/src/fields/inputFields/fields/Suggester/SuggesterHelper';
import type { IModal } from 'meta-bind-core/src/modals/IModal';
import type { ModalContent } from 'meta-bind-core/src/modals/ModalContent';
import type { ButtonBuilderModalOptions } from 'meta-bind-core/src/modals/modalContents/buttonBuilder/ButtonBuilderModal';
import { ButtonBuilderModal } from 'meta-bind-core/src/modals/modalContents/buttonBuilder/ButtonBuilderModal';
import { SvelteModalContent } from 'meta-bind-core/src/modals/modalContents/SvelteModalContent';
import type { SelectModalContent } from 'meta-bind-core/src/modals/SelectModalContent';
import { CommandSelectModal } from 'meta-bind-core/src/modals/selectModalContents/CommandSelectModal';
import { FileSelectModal } from 'meta-bind-core/src/modals/selectModalContents/FileSelectModal';
import { FolderSelectModal } from 'meta-bind-core/src/modals/selectModalContents/FolderSelectModal';
import { SuggesterSelectModal } from 'meta-bind-core/src/modals/selectModalContents/SuggesterSelectModal';
import type { ErrorCollection } from 'meta-bind-core/src/utils/errors/ErrorCollection';
import type { ContextMenuItemDefinition, IContextMenu } from 'meta-bind-core/src/utils/IContextMenu';
import type { IFuzzySearch } from 'meta-bind-core/src/utils/IFuzzySearch';
import type { IJsRenderer } from 'meta-bind-core/src/utils/IJsRenderer';
import type { MBLiteral } from 'meta-bind-core/src/utils/Literal';
import { mount, unmount } from 'svelte';
import type { z } from 'zod';
import type { MB_Comps, MetaBind } from '..';
import DatePickerInput from 'meta-bind-core/src/fields/inputFields/fields/DatePicker/DatePicker.svelte';
import ImageSuggesterModalComponent from 'meta-bind-core/src/modals/modalContents/ImageSuggesterModalComponent.svelte';
import TextPromptModalContent from 'meta-bind-core/src/modals/modalContents/TextPromptModalContent.svelte';
import ErrorCollectionComponent from 'meta-bind-core/src/utils/errors/ErrorCollectionComponent.svelte';
import ErrorIndicatorComponent from 'meta-bind-core/src/utils/errors/ErrorIndicatorComponent.svelte';

export interface ErrorIndicatorProps {
	errorCollection: ErrorCollection;
	code?: string | undefined;
	text?: string | undefined;
	errorText?: string | undefined;
	warningText?: string | undefined;
}

export interface Command {
	id: string;
	name: string;
}

export interface ModalOptions {
	title: string;
	classes?: string[];
}

export interface TextPromptModalOptions extends ModalOptions {
	value: string;
	subTitle: string;
	multiline: boolean;
	onSubmit: (value: string) => void;
	onCancel: () => void;
}

export const IMAGE_FILE_EXTENSIONS = [
	'apng',
	'avif',
	'gif',
	'jpg',
	'jpeg',
	'jfif',
	'pjpeg',
	'pjp',
	'png',
	'svg',
	'webp',
];
export const IMAGE_FILE_EXTENSIONS_WITH_DOTS = IMAGE_FILE_EXTENSIONS.map(ext => `.${ext}`);

export abstract class InternalAPI<Components extends MB_Comps> {
	readonly mb: MetaBind<Components>;

	constructor(mb: MetaBind<Components>) {
		this.mb = mb;
	}

	// eslint-disable-next-line @typescript-eslint/no-explicit-any
	abstract getLifecycleHookValidator(): z.ZodType<LifecycleHook, any, any>;

	/**
	 * Get the options for the image suggester input field.
	 *
	 * @param inputField
	 */
	abstract getImageSuggesterOptions(inputField: ImageSuggesterLikeIPF): SuggesterOption<string>[];

	/**
	 * Get the options for the suggester input field.
	 *
	 * @param inputField
	 */
	abstract getSuggesterOptions(inputField: SuggesterLikeIFP): SuggesterOption<MBLiteral>[];

	/**
	 * Render markdown to an element.
	 *
	 * @param markdown
	 * @param element
	 * @param filePath
	 *
	 * @returns Cleanup callback.
	 */
	abstract renderMarkdown(markdown: string, element: HTMLElement, filePath: string): Promise<() => void>;

	/**
	 * Runs a command by its id.
	 *
	 * @param id
	 */
	abstract executeCommandById(id: string): boolean;

	/**
	 * Check if the js engine plugin is available.
	 */
	abstract isJsEngineAvailable(): boolean;

	/**
	 *  Run a file using js engine.
	 *
	 * @param filePath
	 * @param callingFilePath
	 * @param configOverrides
	 * @param container
	 *
	 * @returns Cleanup callback.
	 */
	abstract jsEngineRunFile(
		filePath: string,
		callingFilePath: string,
		configOverrides: Record<string, unknown>,
		container?: HTMLElement,
	): Promise<() => void>;

	/**
	 * Run code using js engine.
	 *
	 * @param code
	 * @param callingFilePath
	 * @param contextOverrides
	 * @param container
	 *
	 * @returns Cleanup callback.
	 */
	abstract jsEngineRunCode(
		code: string,
		callingFilePath: string,
		contextOverrides: Record<string, unknown>,
		container?: HTMLElement,
	): Promise<() => void>;

	/**
	 * Execute code using js engine with the given globals.
	 *
	 * @param code
	 * @param globals
	 * @param expression If true, evaluate code as an expression instead of as a function body.
	 */
	abstract jsEngineExecuteCustom(
		code: string,
		globals: Record<string, unknown>,
		expression?: boolean,
	): Promise<unknown>;

	/**
	 * Creates a js renderer, used for the js view field.
	 *
	 * @param container
	 * @param filePath
	 * @param code
	 * @param hidden
	 */
	abstract createJsRenderer(container: HTMLElement, filePath: string, code: string, hidden: boolean): IJsRenderer;

	/**
	 * Shows a notice to the user.
	 *
	 * @param message
	 */
	abstract showNotice(message: string): void;

	abstract parseYaml(yaml: string): unknown;

	abstract stringifyYaml(yaml: unknown): string;

	/**
	 * Add an icon to an element.
	 *
	 * @param element
	 * @param icon
	 */
	abstract setIcon(element: HTMLElement, icon: string): void;

	/**
	 * Get the uri for a path to an image.
	 *
	 * @param imagePath
	 */
	abstract imagePathToUri(imagePath: string): string;

	/**
	 * List all commands.
	 */
	abstract getAllCommands(): Command[];

	/**
	 * Creates a search modal with the given content.
	 *
	 * @param content
	 */
	abstract createSearchModal<T>(content: SelectModalContent<T>): IModal;

	/**
	 * Creates a modal with the given content.
	 *
	 * @param content
	 * @param options
	 */
	abstract createModal(content: ModalContent, options?: ModalOptions): IModal;

	/**
	 * Creates a fuzzy search instance.
	 */
	abstract createFuzzySearch(): IFuzzySearch;

	abstract createContextMenu(items: ContextMenuItemDefinition[]): IContextMenu;

	abstract createDate(input?: string | Date, format?: string): MetaBindDate;

	abstract evaluateTemplaterTemplate(templateFilePath: string, targetFilePath: string): Promise<string>;

	abstract createNoteWithTemplater(
		templateFilePath: string,
		folderPath?: string,
		fileName?: string,
		openNote?: boolean,
		newTab?: boolean,
	): Promise<string | undefined>;

	openCommandSelectModal(selectCallback: (selected: Command) => void): void {
		this.createSearchModal(new CommandSelectModal(this.mb, selectCallback)).open();
	}

	openFileSelectModal(selectCallback: (selected: string) => void): void {
		this.createSearchModal(new FileSelectModal(this.mb, selectCallback)).open();
	}

	openFilteredFileSelectModal(
		selectCallback: (selected: string) => void,
		filterFunction: (filePath: string) => boolean,
	): void {
		this.createSearchModal(new FileSelectModal(this.mb, selectCallback, filterFunction)).open();
	}

	openMarkdownFileSelectModal(selectCallback: (selected: string) => void): void {
		this.openFilteredFileSelectModal(selectCallback, filePath => filePath.endsWith('.md'));
	}

	openImageFileSelectModal(selectCallback: (selected: string) => void): void {
		this.openFilteredFileSelectModal(selectCallback, filePath =>
			IMAGE_FILE_EXTENSIONS_WITH_DOTS.some(ext => filePath.endsWith(ext)),
		);
	}

	openFolderSelectModal(selectCallback: (selected: string) => void): void {
		this.createSearchModal(new FolderSelectModal(this.mb, selectCallback)).open();
	}

	openButtonBuilderModal(options: ButtonBuilderModalOptions): void {
		this.createModal(new ButtonBuilderModal(this.mb, options), { title: 'Meta Bind Button Builder' }).open();
	}

	openSuggesterModal(
		inputField: SuggesterLikeIFP,
		selectCallback: (selected: SuggesterOption<MBLiteral>) => void,
	): void {
		this.createSearchModal(new SuggesterSelectModal(this.mb, selectCallback, inputField)).open();
	}

	openImageSuggesterModal(
		inputField: ImageSuggesterLikeIPF,
		canSelectNone: boolean,
		selectCallback: (selected: string | undefined) => void,
	): void {
		this.createModal(
			new SvelteModalContent((modal, targetEl) => {
				return mount(ImageSuggesterModalComponent, {
					target: targetEl,
					props: {
						mb: this.mb,
						options: this.getImageSuggesterOptions(inputField),
						canSelectNone: canSelectNone,
						onSelect: (item: string | undefined): void => {
							selectCallback(item);
							modal.closeModal();
						},
						onCancel: () => {
							modal.closeModal();
						},
					},
				});
			}),
			{
				title: 'Select an image from your Vault',
				classes: ['mb-image-suggester-modal'],
			},
		).open();
	}

	openDatePickerModal(value: MetaBindDate | null, setValue: (value: MetaBindDate | null) => void): void {
		this.createModal(
			new SvelteModalContent((modal, targetEl) => {
				return mount(DatePickerInput, {
					target: targetEl,
					props: {
						mb: this.mb,
						selectedDate: value,
						dateChangeCallback: (value: MetaBindDate | null): void => {
							setValue(value);
							modal.closeModal();
						},
					},
				});
			}),
			{
				title: 'Meta Bind date picker',
			},
		).open();
	}

	openTextPromptModal(options: TextPromptModalOptions): void {
		this.createModal(
			new SvelteModalContent((modal, targetEl) => {
				return mount(TextPromptModalContent, {
					target: targetEl,
					props: {
						options: {
							...options,
							onSubmit: (value: string): void => {
								options.onSubmit(value);
								modal.closeModal();
							},
							onCancel: (): void => {
								options.onCancel();
								modal.closeModal();
							},
						},
					},
				});
			}),
			options,
		).open();
	}

	openErrorCollectionViewModal(settings: ErrorIndicatorProps): void {
		this.createModal(
			new SvelteModalContent((_modal, targetEl) => {
				return mount(ErrorCollectionComponent, {
					target: targetEl,
					props: {
						settings: settings,
					},
				});
			}),
			{
				title: 'Meta Bind error overview',
				classes: ['mb-error-collection-modal', 'markdown-rendered'],
			},
		).open();
	}

	/**
	 * Create an error indicator in the given element.
	 * Returns a cleanup function.
	 *
	 * @param element
	 * @param settings
	 */
	createErrorIndicator(element: HTMLElement, settings: ErrorIndicatorProps): () => void {
		const component = mount(ErrorIndicatorComponent, {
			target: element,
			props: {
				mb: this.mb,
				settings: settings,
			},
		});

		return () => {
			void unmount(component);
		};
	}
}
