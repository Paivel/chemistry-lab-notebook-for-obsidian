import type { PropAccessResult } from 'meta-bind-core/src/utils/prop/PropAccess';
import type { PropPath } from 'meta-bind-core/src/utils/prop/PropPath';

export class PropUtils {
	static get(obj: unknown, path: PropPath): unknown {
		return path.get(obj).child;
	}

	static tryGet(obj: unknown, path: PropPath): unknown {
		return path.tryGet(obj)?.child;
	}

	static fullGet(obj: unknown, path: PropPath): PropAccessResult {
		return path.get(obj);
	}

	static set(obj: unknown, path: PropPath, value: unknown): void {
		path.set(obj, value);
	}

	static setAndCreate(obj: unknown, path: PropPath, value: unknown): void {
		path.setAndCreate(obj, value);
	}
}
