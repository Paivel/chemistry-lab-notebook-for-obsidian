/**
 * Clamp
 *
 * @param num
 * @param min
 * @param max
 */
export function clamp(num: number, min: number, max: number): number {
	return Math.min(Math.max(num, min), max);
}

/**
 * Clamp
 *
 * @param num
 * @param min
 * @param max
 */
export function optClamp(num: number | undefined, min: number, max: number): number | undefined {
	return num !== undefined ? Math.min(Math.max(num, min), max) : undefined;
}

export function remapRange(
	old_value: number,
	old_min: number,
	old_max: number,
	new_min: number,
	new_max: number,
): number {
	return ((old_value - old_min) / (old_max - old_min)) * (new_max - new_min) + new_min;
}

/**
 * js can't even implement modulo correctly...
 *
 * @param n
 * @param m
 */
export function mod(n: number, m: number): number {
	return ((n % m) + m) % m;
}

/**
 * Checks if 2 arrays contain equal values, the arrays should have the same datatype. Order of the elements matters.
 *
 * @param arr1
 * @param arr2
 */
export function areArraysEqual<T>(arr1: T[] | undefined, arr2: T[] | undefined): boolean {
	if (arr1 == null && arr2 == null) {
		return true;
	}
	if (arr1 == null || arr2 == null) {
		return false;
	}

	if (arr1.length !== arr2.length) {
		return false;
	}

	for (let i = 0; i < arr1.length; i++) {
		if (arr1[i] !== arr2[i]) {
			return false;
		}
	}

	return true;
}

export function areObjectsEqual(obj1: unknown, obj2: unknown): boolean {
	// Fast path: identical references and primitives (note: NaN !== NaN)
	if (obj1 === obj2) {
		return true;
	}

	// Treat NaN as equal to NaN
	if (typeof obj1 === 'number' && typeof obj2 === 'number') {
		if (Number.isNaN(obj1) && Number.isNaN(obj2)) {
			return true;
		}
	}

	// Distinguish null and undefined explicitly
	if (obj1 === null || obj2 === null) {
		return obj1 === obj2;
	}
	if (obj1 === undefined || obj2 === undefined) {
		return obj1 === obj2;
	}

	if (typeof obj1 !== typeof obj2) {
		return false;
	}

	// Non-objects (including functions) already handled by reference/strict-equality above
	if (typeof obj1 !== 'object') {
		return obj1 === obj2;
	}

	// At this point both are non-null objects
	// Date handling
	if (obj1 instanceof Date && obj2 instanceof Date) {
		return obj1.getTime() === obj2.getTime();
	}

	// Array handling
	const isArray1 = Array.isArray(obj1);
	const isArray2 = Array.isArray(obj2);
	if (isArray1 || isArray2) {
		if (!isArray1 || !isArray2) return false;
		const a1 = obj1 as unknown[];
		const a2 = obj2 as unknown[];
		if (a1.length !== a2.length) return false;
		for (let i = 0; i < a1.length; i++) {
			if (!areObjectsEqual(a1[i], a2[i])) return false;
		}
		return true;
	}

	// Plain object: compare keys and values
	const keys1 = Object.keys(obj1);
	const keys2 = Object.keys(obj2);
	if (keys1.length !== keys2.length) return false;

	const keys2Set = new Set(keys2);
	for (const k of keys1) {
		if (!keys2Set.has(k)) return false;
		const v1 = (obj1 as Record<string, unknown>)[k];
		const v2 = (obj2 as Record<string, unknown>)[k];
		if (!areObjectsEqual(v1, v2)) return false;
	}

	return true;
}

/**
 * Checks if arr starts with base.
 *
 * @param arr
 * @param base
 */
export function arrayStartsWith<T>(arr: T[], base: T[]): boolean {
	for (let i = 0; i < base.length; i++) {
		if (arr[i] !== base[i]) {
			return false;
		}
	}

	return true;
}

export function isTruthy(value: unknown): boolean {
	return !!value;
}

export function isFalsy(value: unknown): boolean {
	return !value;
}

export function deepFreeze<T extends object>(object: T): Readonly<T>;
export function deepFreeze<T extends object>(object: T | undefined): Readonly<T | undefined>;
export function deepFreeze<T extends object>(object: T | undefined): Readonly<T | undefined> {
	if (object === undefined) {
		return object;
	}

	// Retrieve the property names defined on object
	const propNames: (string | symbol)[] = Reflect.ownKeys(object);

	// Freeze properties before freezing self
	for (const name of propNames) {
		// @ts-ignore
		const value: unknown = object[name];

		if ((value && typeof value === 'object') || typeof value === 'function') {
			deepFreeze(value);
		}
	}

	return Object.freeze(object);
}

export function getUUID(): string {
	return window.crypto.randomUUID();
}

export function isUrl(str: string): boolean {
	try {
		new URL(str);
		return true;
	} catch (_) {
		return false;
	}
}

export function tryParseUrl(str: string): URL | undefined {
	try {
		return new URL(str);
	} catch (_) {
		return undefined;
	}
}

// inspired by https://stackoverflow.com/a/48764436
export class DecimalPrecision {
	static round(value: number, decimalPlaces: number = 0): number {
		const p = Math.pow(10, decimalPlaces || 0);
		const n = value * p * (1 + Number.EPSILON);
		return Math.round(n) / p;
	}

	static ceil(value: number, decimalPlaces: number = 0): number {
		const p = Math.pow(10, decimalPlaces || 0);
		const n = value * p * (1 - Math.sign(value) * Number.EPSILON);
		return Math.ceil(n) / p;
	}

	static floor(value: number, decimalPlaces: number = 0): number {
		const p = Math.pow(10, decimalPlaces || 0);
		const n = value * p * (1 + Math.sign(value) * Number.EPSILON);
		return Math.floor(n) / p;
	}

	static trunc(value: number, decimalPlaces: number = 0): number {
		return value < 0 ? DecimalPrecision.ceil(value, decimalPlaces) : DecimalPrecision.floor(value, decimalPlaces);
	}

	static toFixed(value: number, decimalPlaces: number = 0): string {
		return DecimalPrecision.round(value, decimalPlaces).toFixed(decimalPlaces || 0);
	}
}

export function openURL(link: string): void {
	window.open(link, '_blank');
}

export type Tuple<T> = [T, ...T[]];

export function toEnumeration(
	arr: string[],
	map: (x: string) => string,
	separator: string = ', ',
	lastSeparator: string = 'and',
): string {
	if (arr.length === 0) {
		return '';
	}

	arr = arr.map(map);

	if (arr.length === 1) {
		return arr[0];
	}

	if (arr.length === 2) {
		return `${arr[0]} ${lastSeparator} ${arr[1]}`;
	}

	return `${arr.slice(0, -1).join(separator)} ${lastSeparator} ${arr.slice(-1)[0]}`;
}

export function expectType<T>(_: T): void {
	// no op
}

export function getFolderPathFromFilePath(filePath: string): string {
	const pathSeparator = filePath.lastIndexOf('/');
	if (pathSeparator === -1) {
		return '';
	}
	return filePath.substring(0, pathSeparator);
}

/**
 * Joins the given paths together without duplicate slashes.
 */
export function joinPath(...paths: string[]): string {
	if (paths.length === 0) {
		return '/';
	}
	if (paths.length === 1) {
		return cleanPath(paths[0]);
	}

	let result = paths[0].startsWith('/') ? paths[0].substring(1) : paths[0];
	for (let i = 1; i < paths.length; i++) {
		if (paths[i] === '' || paths[i] === '/') {
			continue;
		}

		const endsWithSlash = result.endsWith('/');
		const startsWithSlash = paths[i].startsWith('/');

		if (endsWithSlash && startsWithSlash) {
			result += paths[i].substring(1);
		} else if (!endsWithSlash && !startsWithSlash) {
			result += '/' + paths[i];
		} else {
			result += paths[i];
		}
	}

	return cleanPath(result);
}

export function cleanPath(path: string): string {
	if (path.startsWith('/')) {
		path = path.substring(1);
	}
	if (path.endsWith('/')) {
		path = path.substring(0, path.length - 1);
	}
	return path === '' ? '/' : path;
}

/**
 * Ensures that the file path has the given extension.
 */
export function ensureFileExtension(filePath: string, extension: string): string {
	extension = extension.startsWith('.') ? extension : '.' + extension;

	if (filePath.endsWith(extension)) {
		return filePath;
	}

	return filePath + extension;
}

export function toArray<T>(value: T | T[] | undefined): T[] {
	if (value === undefined) {
		return [];
	}
	return Array.isArray(value) ? value : [value];
}
