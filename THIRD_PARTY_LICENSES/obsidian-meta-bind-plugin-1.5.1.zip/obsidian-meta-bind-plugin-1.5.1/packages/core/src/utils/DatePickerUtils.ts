import type { Weekday } from 'meta-bind-core/src/Settings';
import { getWeekdayByName, monthNames, weekdays } from 'meta-bind-core/src/Settings';
import { mod } from 'meta-bind-core/src/utils/Utils';

export let firstWeekday: Weekday = weekdays[1];

export function setFirstWeekday(weekdayName: string): void {
	firstWeekday = getWeekdayByName(weekdayName);
}

export function getMonthName(index: number): string {
	return monthNames[index];
}

export function getDateRows(monthIndex: number, year: number): number[] {
	const days: number = new Date(year, monthIndex + 1, 0).getDate(); // amount of days in month
	let rows: number[] = new Array(42).fill(0) as number[]; // empty 42 long array (28 + 7 + 7)
	const startIndex: number = getWeekDay(new Date(year, monthIndex, 1)); // index offset based on weekday of first day in month

	for (let i = 0; i < days; i++) {
		rows[i + startIndex] = i + 1;
	}

	rows = rows[rows.length - 7] ? rows : rows.slice(0, -7); // slice last week if it is empty
	rows = rows[rows.length - 7] ? rows : rows.slice(0, -7); // slice last week if it is empty

	return rows;
}

// first day of the week is monday where I live
export function getWeekDay(date: Date): number {
	return mod(date.getDay() - firstWeekday.index, 7);
}

// first day of the week is monday where I live
export function getWeekDays(): string[] {
	const sortedWeekdays: Weekday[] = weekdays
		.map(x => ({
			index: mod(x.index - firstWeekday.index, 7),
			name: x.name,
			shortName: x.shortName,
		}))
		.sort((a, b) => {
			return a.index - b.index;
		});

	return sortedWeekdays.map(x => x.shortName);
}
