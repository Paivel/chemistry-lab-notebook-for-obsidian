import type { FilePathMetadataCacheItem } from 'meta-bind-core/src/metadata/MetadataCacheItem';
import type { MetadataManager } from 'meta-bind-core/src/metadata/MetadataManager';
import type { Metadata } from 'meta-bind-core/src/metadata/MetadataSource';
import { FilePathMetadataSource } from 'meta-bind-core/src/metadata/MetadataSource';
import type { PublishMetaBind } from 'meta-bind-publish/src/main';

export class PublishMetadataSource extends FilePathMetadataSource<FilePathMetadataCacheItem> {
	public readonly mb: PublishMetaBind;

	constructor(mb: PublishMetaBind, id: string, manager: MetadataManager) {
		super(id, manager);
		this.mb = mb;
	}

	public readExternal(storagePath: string): Metadata {
		const frontmatter = publish.site.cache.cache[storagePath]?.frontmatter;

		return structuredClone(frontmatter) ?? {};
	}

	getDefaultCacheItem(storagePath: string): FilePathMetadataCacheItem {
		const frontmatter = publish.site.cache.cache[storagePath]?.frontmatter;

		if (MB_DEBUG)
			console.log('meta-bind | Obs Source >> loaded frontmatter', structuredClone(frontmatter), storagePath);

		return {
			data: structuredClone(frontmatter) ?? {},
			storagePath: storagePath,
			...this.manager.constructDefaultCacheItem(),
		};
	}

	syncExternal(_: FilePathMetadataCacheItem): Promise<void> {
		return Promise.resolve();
	}
}
