<%* 
new Notice("Hello!");
-%>